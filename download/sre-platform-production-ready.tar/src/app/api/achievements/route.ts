import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserId } from '@/lib/auth-helper';
import { calculateLevel } from '@/lib/gamification';
import { checkAndNotifyEligibleAchievements } from '@/lib/achievements';
import { safeJsonParse } from '@/lib/utils';

interface CriteriaCheck {
  type: string;
  value: number;
}

async function checkCriteria(userId: string, criteria: CriteriaCheck): Promise<{ current: number; met: boolean }> {
  const profile = await db.profile.findUnique({ where: { userId } });
  if (!profile) return { current: 0, met: false };

  let current = 0;

  switch (criteria.type) {
    case 'learning_entries':
      current = await db.learningEntry.count({ where: { userId } });
      break;
    case 'learning_topics':
      current = await db.learningTopic.count({ where: { userId } });
      break;
    case 'learning_notes': {
      const entries = await db.learningEntry.findMany({ where: { userId, content: { not: null } } });
      current = entries.filter((e: any) => e.content && e.content.trim().length > 0).length;
      break;
    }
    case 'learning_duration': {
      const result = await db.learningEntry.aggregate({ where: { userId }, _sum: { duration: true } });
      current = result._sum.duration || 0;
      break;
    }
    case 'learning_shared':
      current = await db.learningTopic.count({ where: { userId, isSharedCollection: true } });
      break;
    case 'learning_deep_topic': {
      const topics = await db.learningTopic.findMany({ where: { userId }, include: { _count: { select: { entries: true } } } });
      current = topics.reduce((max: number, t: any) => Math.max(max, t._count.entries), 0);
      break;
    }
    case 'fitness_workouts':
      current = await db.fitnessWorkoutLog.count({ where: { userId } });
      break;
    case 'fitness_meals':
      current = await db.fitnessFoodLog.count({ where: { userId } });
      break;
    case 'fitness_weights':
      current = await db.fitnessWeightLog.count({ where: { userId } });
      break;
    case 'fitness_workout_duration': {
      const result = await db.fitnessWorkoutLog.aggregate({ where: { userId }, _sum: { duration: true } });
      current = result._sum.duration || 0;
      break;
    }
    case 'weight_training_sessions':
      current = await db.fitnessWorkoutLog.count({ where: { userId, workoutType: 'Weight Training' } });
      break;
    case 'weight_training_load_increase': {
      const sessions = await db.fitnessWorkoutLog.findMany({
        where: { userId, workoutType: 'Weight Training', loadKg: { not: null } },
        orderBy: { createdAt: 'asc' },
        select: { loadKg: true }
      });
      const hasIncrease = sessions.length >= 2 && sessions.some((s, i) =>
        i > 0 && (s.loadKg ?? 0) > (sessions[i - 1].loadKg ?? 0)
      );
      current = hasIncrease ? 1 : 0;
      break;
    }
    case 'weight_training_rep_increase': {
      const sessions = await db.fitnessWorkoutLog.findMany({
        where: { userId, workoutType: 'Weight Training', reps: { not: null } },
        orderBy: { createdAt: 'asc' },
        select: { reps: true }
      });
      const hasIncrease = sessions.length >= 2 && sessions.some((s, i) =>
        i > 0 && (s.reps ?? 0) > (sessions[i - 1].reps ?? 0)
      );
      current = hasIncrease ? 1 : 0;
      break;
    }
    case 'weight_training_set_increase': {
      const sessions = await db.fitnessWorkoutLog.findMany({
        where: { userId, workoutType: 'Weight Training', sets: { not: null } },
        orderBy: { createdAt: 'asc' },
        select: { sets: true }
      });
      const hasIncrease = sessions.length >= 2 && sessions.some((s, i) =>
        i > 0 && (s.sets ?? 0) > (sessions[i - 1].sets ?? 0)
      );
      current = hasIncrease ? 1 : 0;
      break;
    }
    case 'weight_training_intermediate': {
      const sessions = await db.fitnessWorkoutLog.findMany({
        where: { userId, workoutType: 'Weight Training', loadKg: { not: null } },
        orderBy: { createdAt: 'asc' },
        select: { loadKg: true }
      });
      current = sessions.filter((s, i) =>
        i > 0 && (s.loadKg ?? 0) > (sessions[i - 1].loadKg ?? 0)
      ).length;
      break;
    }
    case 'time_focus':
      current = await db.focusSession.count({ where: { userId, completed: true } });
      break;
    case 'time_tasks':
      current = await db.timeTask.count({ where: { userId, status: 'completed' } });
      break;
    case 'time_focus_duration': {
      const result = await db.focusSession.aggregate({ where: { userId, completed: true }, _sum: { duration: true } });
      current = result._sum.duration || 0;
      break;
    }
    case 'content_posts':
      current = await db.post.count({ where: { userId } });
      break;
    case 'content_scripts':
      current = await db.contentEntry.count({ where: { userId, series: { category: 'script' } } });
      break;
    case 'content_videos':
      current = await db.contentEntry.count({ where: { userId, series: { category: 'video' } } });
      break;
    case 'content_blogs':
      current = await db.contentEntry.count({ where: { userId, series: { category: 'blog' } } });
      break;
    case 'content_live_posted':
      current = await db.contentEntry.count({ where: { userId, liveStatus: 'posted' } });
      break;
    case 'content_live_pipeline_blog':
      current = await db.contentEntry.count({ where: { userId, contentType: 'blog', liveStatus: 'posted' } });
      break;
    case 'content_live_pipeline_video':
      current = await db.contentEntry.count({ where: { userId, contentType: 'video', liveStatus: 'posted' } });
      break;
    case 'content_live_pipeline_post':
      current = await db.contentEntry.count({ where: { userId, contentType: 'post', liveStatus: 'posted' } });
      break;
    case 'streak':
      current = profile.currentStreak || 0;
      break;
    case 'longest_streak':
      current = profile.longestStreak || 0;
      break;
    case 'level':
      current = profile.level || 1;
      break;
    case 'xp':
      current = profile.xp || 0;
      break;
    case 'followers':
      current = await db.follow.count({ where: { followingId: userId, status: 'accepted' } });
      break;
    default:
      current = 0;
  }

  return { current, met: current >= criteria.value };
}

export async function GET() {
  try {
    const userId = await getUserId();

    const allAchievements = await db.achievement.findMany({
      orderBy: [{ category: 'asc' }, { tier: 'asc' }, { xpReward: 'asc' }],
    });

    const userAchievements = await db.userAchievement.findMany({
      where: { userId },
      select: { achievementId: true, unlockedAt: true },
    });

    const unlockedMap = new Map(userAchievements.map((ua) => [ua.achievementId, ua.unlockedAt]));

    // Check eligibility for each achievement
    const achievementsWithStatus = await Promise.all(
      allAchievements.map(async (a) => {
        const isUnlocked = unlockedMap.has(a.id);
        let eligible = false;
        let currentProgress = 0;

        if (!isUnlocked && a.criteria) {
          try {
            const criteria = safeJsonParse<CriteriaCheck>(a.criteria, { type: '', value: 0 });
            const check = await checkCriteria(userId, criteria);
            eligible = check.met;
            currentProgress = check.current;
          } catch {
            eligible = false;
          }
        } else if (isUnlocked) {
          // For unlocked achievements, try to get current progress
          if (a.criteria) {
            try {
              const criteria = safeJsonParse<CriteriaCheck>(a.criteria, { type: '', value: 0 });
              const check = await checkCriteria(userId, criteria);
              currentProgress = check.current;
            } catch {
              currentProgress = 0;
            }
          }
        }

        return {
          id: a.id,
          key: a.key,
          name: a.name,
          description: a.description,
          iconEmoji: a.iconEmoji,
          xpReward: a.xpReward,
          tier: a.tier,
          category: a.category,
          criteria: a.criteria,
          unlocked: isUnlocked,
          unlockedAt: unlockedMap.get(a.id)?.toISOString() || null,
          eligible,
          currentProgress,
        };
      })
    );

    // Auto-create notifications for newly eligible achievements (not yet notified)
    const eligibleAchievements = achievementsWithStatus.filter(a => a.eligible && !a.unlocked);
    if (eligibleAchievements.length > 0) {
      // Check which eligible achievements already have an eligible notification (to avoid duplicates)
      // Check ALL notifications (read and unread) to prevent re-creating notifications
      const existingNotifs = await db.notification.findMany({
        where: {
          userId,
          type: 'achievement_eligible',
        },
        select: { data: true },
      });
      const alreadyNotifiedIds = new Set(
        existingNotifs.map(n => { try { return JSON.parse(n.data || '{}').achievementId; } catch { return null; } }).filter(Boolean)
      );

      for (const a of eligibleAchievements) {
        if (!alreadyNotifiedIds.has(a.id)) {
          try {
            await db.notification.create({
              data: {
                userId,
                type: 'achievement_eligible',
                title: 'Achievement Ready!',
                message: `${a.iconEmoji} ${a.name}! +${a.xpReward} XP`,
                data: JSON.stringify({ achievementId: a.id }),
              },
            });
          } catch {}
        }
      }
    }

    const response = NextResponse.json({ achievements: achievementsWithStatus });
    // Prevent browser/CDN caching so achievement eligibility is always fresh
    response.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    return response;
  } catch (error) {
    console.error('Achievements error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const userId = await getUserId();
    const { achievementId } = await request.json();

    if (!achievementId) {
      return NextResponse.json({ error: 'achievementId required' }, { status: 400 });
    }

    const achievement = await db.achievement.findUnique({ where: { id: achievementId } });
    if (!achievement) {
      return NextResponse.json({ error: 'Achievement not found' }, { status: 404 });
    }

    // Check if already unlocked
    const existing = await db.userAchievement.findUnique({
      where: { userId_achievementId: { userId, achievementId } },
    });
    if (existing) {
      return NextResponse.json({ error: 'Already claimed' }, { status: 400 });
    }

    // Verify eligibility
    if (achievement.criteria) {
      try {
        const criteria = safeJsonParse<CriteriaCheck>(achievement.criteria, { type: '', value: 0 });
        const check = await checkCriteria(userId, criteria);
        if (!check.met) {
          return NextResponse.json({ error: 'Criteria not met', current: check.current, required: criteria.value }, { status: 400 });
        }
      } catch {
        return NextResponse.json({ error: 'Invalid criteria' }, { status: 500 });
      }
    }

    // Claim the achievement
    await db.userAchievement.create({
      data: { userId, achievementId },
    });

    // Award XP
    try {
      const profile = await db.profile.findUnique({ where: { userId } });
      if (profile) {
        const newXP = profile.xp + achievement.xpReward;
        const newLevel = calculateLevel(newXP);
        await db.profile.update({
          where: { userId },
          data: { xp: newXP, level: newLevel },
        });
      }
    } catch (e) {
      console.error('XP award error (non-blocking):', e);
    }

    // Create notification
    try {
      await db.notification.create({
        data: {
          userId,
          type: 'achievement',
          message: `Achievement Unlocked: ${achievement.iconEmoji} ${achievement.name}! +${achievement.xpReward} XP`,
        },
      });
    } catch (e) {
      console.error('Notification error (non-blocking):', e);
    }

    // Check for other newly eligible achievements after XP increase
    try {
      await checkAndNotifyEligibleAchievements(userId);
    } catch (e) {
      console.error('Achievement eligibility check error (non-blocking):', e);
    }

    return NextResponse.json({
      success: true,
      achievement: {
        id: achievement.id,
        key: achievement.key,
        name: achievement.name,
        iconEmoji: achievement.iconEmoji,
        xpReward: achievement.xpReward,
      },
    });
  } catch (error) {
    console.error('Achievement claim error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
