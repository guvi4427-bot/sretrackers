# S/R/E Platform — Deployment Guide

> **Start / Restart / Explore** — Gamified Self-Growth Platform
> Next.js 16 · Prisma + Turso (libSQL) · Vercel

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Option A: One-Command Deployment](#option-a-one-command-deployment)
3. [Option B: Manual Step-by-Step Deployment](#option-b-manual-step-by-step-deployment)
4. [Option C: GitHub Actions CI/CD](#option-c-github-actions-cicd)
5. [Environment Variables Reference](#environment-variables-reference)
6. [Post-Deployment Verification](#post-deployment-verification)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before deploying, you need the following accounts and tools:

### Accounts

| Account | Purpose | Sign Up |
|---------|---------|---------|
| **Turso** | Cloud SQLite database (libSQL) | [turso.tech](https://turso.tech) |
| **Vercel** | Hosting & deployment platform | [vercel.com](https://vercel.com) |
| **GitHub** | Source code & CI/CD | [github.com](https://github.com) |

### Local Tools

| Tool | Version | Install |
|------|---------|---------|
| **Node.js** | 20+ | [nodejs.org](https://nodejs.org) |
| **Bun** | Latest | [bun.sh](https://bun.sh) |
| **Git** | 2.x | [git-scm.com](https://git-scm.com) |
| **Turso CLI** | Latest | `curl -sSfL https://get.tur.so/install.sh \| bash` |
| **Vercel CLI** | Latest | `npm i -g vercel` |

### Verify tools are installed

```bash
node --version    # v20+
bun --version     # latest
turso --version   # latest
vercel --version  # latest
```

---

## Option A: One-Command Deployment

The fastest way to deploy — a single script handles everything.

### Step 1: Clone and enter the project

```bash
git clone <your-repo-url> sre-platform
cd sre-platform
bun install
```

### Step 2: Run the complete deployment script

```bash
bash scripts/deploy-complete.sh
```

This master script runs all four phases sequentially:

| Phase | Script | What it does |
|-------|--------|--------------|
| 1 | `scripts/setup-turso.sh` | Creates Turso DB, gets credentials, pushes schema |
| 2 | `scripts/deploy-vercel.sh` | Links project, sets env vars, deploys to Vercel |
| 3 | `scripts/seed-production.sh` | Seeds admin user & achievements |
| 4 | Verification | Health check on deployed URL |

### Step 3: Follow the interactive prompts

The script will prompt you for:
- Turso authentication (browser-based)
- Vercel authentication (browser-based)
- Vercel project configuration (project name, framework)
- Admin user credentials

### Step 4: Visit your app!

The script outputs your production URL. Open it and log in with your admin credentials.

### Skipping steps

If you've already completed some phases, you can skip them:

```bash
# Skip Turso setup (already have a database)
bash scripts/deploy-complete.sh --skip-turso

# Only run the Vercel deployment
bash scripts/deploy-complete.sh --vercel-only

# Only seed the database
bash scripts/deploy-complete.sh --seed-only
```

---

## Option B: Manual Step-by-Step Deployment

If you prefer full control over each step, follow this guide.

### Step 1: Set up Turso Database

#### 1a. Install and authenticate with Turso CLI

```bash
# Install Turso CLI
curl -sSfL https://get.tur.so/install.sh | bash

# Authenticate (opens browser)
turso auth login

# Verify
turso auth whoami
```

#### 1b. Create the database

```bash
# Create database with WAL mode for better performance
turso db create sre-platform --enable-wal

# Get the database URL
turso db show sre-platform --url
# Output: libsql://sre-platform-<your-org>.turso.io

# Create an auth token
turso db tokens create sre-platform
# Output: eyJhbGciOi...
```

#### 1c. Save credentials

```bash
# Note these values — you'll need them for Vercel environment variables
DATABASE_URL="libsql://sre-platform-<your-org>.turso.io"
TURSO_AUTH_TOKEN="eyJhbGciOi..."
```

#### 1d. Push the Prisma schema

```bash
# Generate Prisma client
npx prisma generate

# Push schema to Turso
DATABASE_URL="libsql://sre-platform-<your-org>.turso.io" \
TURSO_AUTH_TOKEN="eyJhbGciOi..." \
npx prisma db push
```

### Step 2: Deploy to Vercel

#### 2a. Install and authenticate with Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Authenticate (opens browser)
vercel login

# Verify
vercel whoami
```

#### 2b. Link and deploy

```bash
# Link project to Vercel
vercel link
# Choose: Set up and deploy? Y
# Choose: Framework: Next.js
# Choose: Project name: sre-platform

# Set environment variables
vercel env add DATABASE_URL production
# Paste: libsql://sre-platform-<your-org>.turso.io

vercel env add TURSO_AUTH_TOKEN production
# Paste: eyJhbGciOi...

# Generate a NEXTAUTH_SECRET
openssl rand -base64 32
# Copy the output

vercel env add NEXTAUTH_SECRET production
# Paste the generated secret

vercel env add NEXTAUTH_URL production
# Paste: https://sre-platform.vercel.app

# Deploy to production
vercel --prod
```

#### 2c. Note your deployment URL

After deployment, Vercel outputs your production URL:
```
https://sre-platform.vercel.app
```

### Step 3: Seed the Production Database

```bash
# Run the seed script with your Turso credentials
DATABASE_URL="libsql://sre-platform-<your-org>.turso.io" \
TURSO_AUTH_TOKEN="eyJhbGciOi..." \
bash scripts/seed-production.sh
```

Or with custom admin credentials:

```bash
DATABASE_URL="libsql://sre-platform-<your-org>.turso.io" \
TURSO_AUTH_TOKEN="eyJhbGciOi..." \
ADMIN_EMAIL="your-email@example.com" \
ADMIN_USERNAME="admin" \
ADMIN_PASSWORD="YourSecurePassword123!" \
ADMIN_PHONE="+1234567890" \
bash scripts/seed-production.sh --non-interactive
```

### Step 4: Verify

```bash
# Health check
curl https://sre-platform.vercel.app/api/health

# Visit the app
open https://sre-platform.vercel.app
```

---

## Option C: GitHub Actions CI/CD

Set up automatic deployments when you push to the `main` branch.

### Step 1: Push to GitHub

```bash
# Initialize git (if not already)
git init
git add .
git commit -m "Initial commit"

# Add remote and push
git remote add origin https://github.com/<your-username>/sre-platform.git
git branch -M main
git push -u origin main
```

### Step 2: Configure GitHub Secrets

Go to your repository → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

Add the following secrets:

| Secret Name | Value | How to get it |
|-------------|-------|---------------|
| `DATABASE_URL` | `libsql://sre-platform-<org>.turso.io` | `turso db show sre-platform --url` |
| `TURSO_AUTH_TOKEN` | `eyJhbGciOi...` | `turso db tokens create sre-platform` |
| `VERCEL_TOKEN` | Vercel API token | Vercel Dashboard → Settings → Tokens |
| `VERCEL_ORG_ID` | Your org ID | `.vercel/project.json` or Vercel Dashboard |
| `VERCEL_PROJECT_ID` | Project ID | `.vercel/project.json` or Vercel Dashboard |
| `NEXTAUTH_SECRET` | Random base64 string | `openssl rand -base64 32` |
| `SEED_SECRET` | Secret for seed API | Any secure string (optional) |

#### Getting Vercel secrets

```bash
# After running `vercel link`, check the project file
cat .vercel/project.json

# Or create a token at: https://vercel.com/account/tokens
```

### Step 3: The workflow file

The workflow is already configured at `.github/workflows/deploy.yml`. It runs:

1. **Build & Test** — Installs deps, generates Prisma client, builds Next.js
2. **Database Migration** — Pushes Prisma schema to Turso
3. **Deploy to Vercel** — Deploys the built app to production
4. **Seed Database** — Seeds admin user and achievements
5. **Verify Deployment** — Health check on the deployed URL

### Step 4: Trigger a deployment

```bash
# Push to main triggers automatic deployment
git push origin main

# Or trigger manually in GitHub Actions tab
# Click "Run workflow" → Deploy to Production
```

### Step 5: Monitor deployments

- **GitHub Actions**: Repository → Actions tab
- **Vercel Dashboard**: [vercel.com/dashboard](https://vercel.com/dashboard)
- **Turso Dashboard**: [turso.tech/app](https://turso.tech/app)

---

## Environment Variables Reference

### Required for Production

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Turso database connection URL | `libsql://sre-platform-abc.turso.io` |
| `TURSO_AUTH_TOKEN` | Turso authentication token | `eyJhbGciOi...` |
| `NEXTAUTH_SECRET` | Secret for JWT signing | Output of `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Canonical URL of your app | `https://sre-platform.vercel.app` |

### Optional

| Variable | Description | Default |
|----------|-------------|---------|
| `ADMIN_EMAIL` | Admin user email (for seeding) | `myselfgowtham140707@gmail.com` |
| `ADMIN_USERNAME` | Admin username (for seeding) | `admin` |
| `ADMIN_PASSWORD` | Admin password (for seeding) | `Gowtham@123` |
| `ADMIN_PHONE` | Admin phone (for seeding) | `+918148796055` |
| `SEED_SECRET` | Bearer token for `/api/seed` endpoint | None |

### Development (Local)

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Local SQLite file | `file:./db/custom.db` |

---

## Post-Deployment Verification

### 1. Health Check

```bash
curl -s https://sre-platform.vercel.app/api/health
# Should return 200 OK
```

### 2. Homepage

```bash
curl -s -o /dev/null -w "%{http_code}" https://sre-platform.vercel.app
# Should return 200 or 301/302
```

### 3. Admin Login

1. Visit `https://sre-platform.vercel.app/login`
2. Sign in with admin credentials
3. Verify you're redirected to the dashboard

### 4. API Endpoints

```bash
# Test a protected endpoint (needs auth cookie)
curl -s https://sre-platform.vercel.app/api/achievements
# Should return achievement list or 401
```

### 5. Database Verification

```bash
# Check via Turso CLI
turso db shell sre-platform

# In the shell:
# SELECT COUNT(*) FROM Achievement;
# SELECT COUNT(*) FROM User;
# SELECT email, username FROM User WHERE id IN (SELECT userId FROM AdminRole);
```

### 6. Vercel Logs

```bash
# View real-time logs
vercel logs https://sre-platform.vercel.app --follow
```

---

## Troubleshooting

### Build Errors

#### "Prisma Client could not be generated"

```bash
# Regenerate Prisma client
npx prisma generate

# If using Turso, make sure the adapter is installed
bun add @prisma/adapter-libsql @libsql/client
```

#### "Module not found" errors

```bash
# Clean install
rm -rf node_modules bun.lock
bun install
```

#### Next.js build fails with type errors

```bash
# Check TypeScript errors
npx tsc --noEmit

# If you want to proceed despite type errors, temporarily set in next.config.ts:
# typescript: { ignoreBuildErrors: true }
```

### Database Issues

#### "P2021: The table does not exist"

```bash
# Push the schema again
DATABASE_URL="libsql://..." TURSO_AUTH_TOKEN="..." npx prisma db push
```

#### "Connection refused" or Turso connection errors

1. Verify your `DATABASE_URL` starts with `libsql://`
2. Check that your `TURSO_AUTH_TOKEN` is valid:
   ```bash
   turso db tokens create sre-platform
   ```
3. Check Turso status: [status.turso.tech](https://status.turso.tech)

#### "Authentication failed" on Turso

```bash
# Re-authenticate
turso auth login

# Check your account
turso auth whoami
```

### Vercel Issues

#### Deployment fails

```bash
# Check Vercel build logs
vercel logs --follow

# Try deploying with verbose output
vercel --prod --debug
```

#### Environment variables not taking effect

- Environment variables set via `vercel env add` require a **redeployment** to take effect
- Redeploy: `vercel --prod`
- Or trigger from the Vercel Dashboard → Deployments → Redeploy

#### "404 Not Found" after deployment

1. Make sure `output: "standalone"` is in `next.config.ts` (it is by default)
2. Check that the build command succeeds locally: `bun run build`
3. Verify the framework is set to "Next.js" in Vercel settings

### Authentication Issues

#### "NEXTAUTH_SECRET" error

```bash
# Generate a new secret
openssl rand -base64 32

# Set it in Vercel
vercel env add NEXTAUTH_SECRET production
# Then redeploy: vercel --prod
```

#### Login redirects not working

- Ensure `NEXTAUTH_URL` matches your actual production URL
- If using a custom domain, update `NEXTAUTH_URL` accordingly
- Check that `trustHost: true` is set in the NextAuth config (it is by default)

### General Debugging

#### Enable debug logging

In your Vercel environment, add:
```
DEBUG=prisma:*
```

Then check the Vercel function logs for detailed Prisma queries.

#### Check Turso database directly

```bash
# Open an interactive SQL shell
turso db shell sre-platform

# List all tables
.tables

# Check user count
SELECT COUNT(*) FROM User;

# Check admin users
SELECT u.email, u.username, a.isSuperAdmin 
FROM User u 
JOIN AdminRole a ON u.id = a.userId;
```

#### Reset the database (⚠️ destructive)

```bash
# Delete and recreate the Turso database
turso db destroy sre-platform
turso db create sre-platform --enable-wal

# Push schema and reseed
DATABASE_URL="libsql://..." TURSO_AUTH_TOKEN="..." npx prisma db push
bash scripts/seed-production.sh
```

---

## Quick Reference

| Task | Command |
|------|---------|
| Full deployment | `bash scripts/deploy-complete.sh` |
| Setup Turso only | `bash scripts/setup-turso.sh` |
| Deploy to Vercel only | `bash scripts/deploy-vercel.sh` |
| Seed production DB | `bash scripts/seed-production.sh` |
| Generate NEXTAUTH_SECRET | `openssl rand -base64 32` |
| Get Turso DB URL | `turso db show sre-platform --url` |
| Create Turso token | `turso db tokens create sre-platform` |
| View Vercel logs | `vercel logs --follow` |
| Local development | `bun run dev` |
| Push schema changes | `DATABASE_URL=... TURSO_AUTH_TOKEN=... npx prisma db push` |

---

*Last updated: 2025-01*
